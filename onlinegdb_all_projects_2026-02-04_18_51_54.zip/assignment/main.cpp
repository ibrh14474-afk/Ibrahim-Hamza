/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <stdexcept> // Added for runtime_error

using namespace std;

// 1. Sum of two integers (Correct)
int sum(int x, int y) {
    return x + y;
}

// 2. Count vowels in a string (Correct)
int countVowels(string s) {
    int count = 0;
    for (char c : s) {
        c = tolower(c);
        if (c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
            count++;
    }
    return count;
}

// 3. Average of integers (Improved: added empty vector check)
double average(vector<int> nums) {
    if (nums.empty()) {
        throw runtime_error("Cannot calculate average of an empty vector.");
    }
    int total = 0;
    for (int n : nums)
        total += n;
    return (double)total / nums.size();
}

// 4. Remove vowels from sentence (Correct)
string removeVowels(string s) {
    string result = "";
    for (char c : s) {
        char lower = tolower(c);
        if (!(lower=='a'||lower=='e'||lower=='i'||lower=='o'||lower=='u'))
            result += c;
    }
    return result;
}

// 5. Longest string in list (Improved: added empty vector check)
string longestString(vector<string> words) {
    if (words.empty()) {
        throw runtime_error("Cannot find the longest string in an empty vector.");
    }
    string longest = words[0];
    for (string w : words) {
        if (w.length() > longest.length())
            longest = w;
    }
    return longest;
}

// 6. Median of integers (Improved: added empty vector check)
double median(vector<int> nums) {
    if (nums.empty()) {
        throw runtime_error("Cannot calculate median of an empty vector.");
    }
    sort(nums.begin(), nums.end());
    int n = nums.size();
    if (n % 2 == 0)
        return (nums[n/2 - 1] + nums[n/2]) / 2.0;
    else
        return nums[n/2];
}

// 7. Remove even numbers (Correct)
vector<int> removeEven(vector<int> nums) {
    vector<int> result;
    for (int n : nums) {
        if (n % 2 != 0)
            result.push_back(n);
    }
    return result;
}

// 8. Sort strings alphabetically (Correct)
vector<string> sortStrings(vector<string> words) {
    sort(words.begin(), words.end());
    return words;
}

// 9. Sum of list of integers (Correct)
int sumList(vector<int> nums) {
    int total = 0;
    for (int n : nums)
        total += n;
    return total;
}

// 10. Reverse strings in list (Improved: clarifies intent - returns a new vector)
vector<string> reverseStrings(vector<string> words) { // Parameter passed by value to create a copy
    for (string &w : words)
        reverse(w.begin(), w.end());
    return words; // Returns the modified copy
}

// Example usage might look like this:
 int main() {
     try {
         vector<int> emptyVec;
         cout << "Average: " << average(emptyVec) << endl;
     } catch (const runtime_error& e) {
         cerr << "Error: " << e.what() << endl;
  }
    return 0;
 }


