/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/


#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

std::vector<std::string> sortStrings(std::vector<std::string> list) {
    std::sort(list.begin(), list.end());
    return list;
}

int main() {
    std::vector<std::string> fruits = {"Banana", "Apple", "Elderberry", "Cherry", "Date"};

    std::vector<std::string> sortedFruits = sortStrings(fruits);

    std::cout << "Original list: ";
    for (const std::string& s : fruits) {
        std::cout << s << " ";
    }

    std::cout << "\nSorted list:   ";
    for (const std::string& s : sortedFruits) {
        std::cout << s << " ";
    }
    std::cout << std::endl;

    return 0;
}

    